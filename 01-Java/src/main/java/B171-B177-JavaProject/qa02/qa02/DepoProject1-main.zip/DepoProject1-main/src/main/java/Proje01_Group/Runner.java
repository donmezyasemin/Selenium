package Proje01_Group;



public class Runner {
    public static void main(String[] args) {
        Metodlar metod = new Metodlar();
        metod.hazirTanimliUrunler();
        metod.menu();
    }
}
