package project02;

public class Runner  {

    public static void main(String[] args) {

    Action a =new Action();
    a.homepage();

    }


}
