package project02;

public interface Homepage {
    void mainMenu();
   void homepage();


}
