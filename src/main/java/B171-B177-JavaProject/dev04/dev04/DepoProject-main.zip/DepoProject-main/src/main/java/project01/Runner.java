package project01;

public class Runner extends Action {
    public static void main(String[] args) {

        homepage();

    }
}
