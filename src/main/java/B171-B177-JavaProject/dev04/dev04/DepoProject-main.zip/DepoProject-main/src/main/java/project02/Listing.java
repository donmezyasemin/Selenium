package project02;

public interface Listing {
    void listing();
}
