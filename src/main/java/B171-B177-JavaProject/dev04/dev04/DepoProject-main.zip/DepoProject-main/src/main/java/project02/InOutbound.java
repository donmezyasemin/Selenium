package project02;

public interface InOutbound {
    void inboundProdct();
    void productOut();
}
