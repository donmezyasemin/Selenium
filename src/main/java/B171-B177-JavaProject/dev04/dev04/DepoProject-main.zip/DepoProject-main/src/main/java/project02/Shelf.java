package project02;

public interface Shelf {

     void assignShelf();
}
