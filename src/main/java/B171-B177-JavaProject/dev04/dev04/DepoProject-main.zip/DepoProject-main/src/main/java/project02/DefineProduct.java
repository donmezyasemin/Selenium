package project02;

public interface DefineProduct {

       void defineProduct();
}
