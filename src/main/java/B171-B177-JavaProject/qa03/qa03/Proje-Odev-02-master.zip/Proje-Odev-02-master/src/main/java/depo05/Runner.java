package depo05;

public class Runner {
    public static void main(String[] args) {
        DepoMethod basla = new DepoMethod( "", "", "", 0, "null");
        basla.giris();
    }
}
