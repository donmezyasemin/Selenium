# Proje-Odev-02
Arkadaşlar merhaba. Projeyi tamamladım. Sadece exception'lar eklenecek. İnceleyebilirsiniz
